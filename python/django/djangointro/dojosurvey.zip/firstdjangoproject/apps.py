from django.apps import AppConfig


class FirstdjangoprojectConfig(AppConfig):
    name = 'firstdjangoproject'
