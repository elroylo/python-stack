from django.urls import path
from . import views
                    
urlpatterns = [
    path('', views.index, name='index-url'),
    path('create_dojo', views.create_dojo, name='create-dojo'),
    path('create_ninja', views.create_ninja, name='create-ninja')
]