from django.apps import AppConfig


class DojoAndNinjasConfig(AppConfig):
    name = 'dojo_and_ninjas'
