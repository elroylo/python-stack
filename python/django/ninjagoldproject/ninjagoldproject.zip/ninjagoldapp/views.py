from django.shortcuts import render, redirect
from random import randint
# Create your views here.
def index(request):
    return render(request, context={'gold':request.session.get('gold', 0)}, template_name='index.html')

def process_money(request):
    money = 0
    if 'gold' in request.session:
        money = request.session['gold']
    else:
        request.session['gold'] = 0
    # add money
    if request.POST.get('place') == "Farm":
        money += randint(10,20)
    if request.POST.get('place') == "Cave":
        money += randint(5,10)
    if request.POST.get('place') == "House":
        money += randint(2,5)
    if request.POST.get('place') == "Casino":
        money += randint(-50,50)    
    # save money
    request.session['gold'] = money
    return redirect(to='index-url')