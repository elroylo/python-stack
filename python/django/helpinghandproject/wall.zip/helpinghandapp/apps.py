from django.apps import AppConfig


class HelpinghandappConfig(AppConfig):
    name = 'helpinghandapp'
