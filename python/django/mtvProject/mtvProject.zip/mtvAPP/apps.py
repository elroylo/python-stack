from django.apps import AppConfig


class MtvappConfig(AppConfig):
    name = 'mtvAPP'
